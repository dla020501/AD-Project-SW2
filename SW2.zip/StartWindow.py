import sys
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import (QMainWindow, QWidget, QPushButton,
    QHBoxLayout, QVBoxLayout, QApplication, QLabel,QGridLayout,
    QComboBox, QLayout)

from PyQt5.QtGui import QFont

from game import GameWindow

class StartWindow(QWidget):
    def __init__(self):
        super().__init__()

        start_sentence1 = QLabel("Let's play tic tac toe !", self)
        start_sentence1.setFont(QFont("궁서", 20))
        start_sentence1.setStyleSheet("Color : blue")
        self.howMany = QComboBox(self)
        self.howMany.addItem("혼자하기")
        self.howMany.addItem("둘이하기")

        self.nxn = QComboBox(self)
        self.nxn.addItem("3x3")
        self.nxn.addItem("4x4")
        self.nxn.addItem("5x5")

        self.startButton = QPushButton("START")
        self.startButton.clicked.connect(self.setWindow)

        hbox1 = QHBoxLayout()
        hbox1.addStretch(1)
        hbox1.addWidget(start_sentence1)
        hbox1.addStretch(1)

        hbox2 = QHBoxLayout()
        hbox2.addWidget(self.howMany)
        hbox2.addWidget(self.nxn)

        vbox = QVBoxLayout()
        vbox.addLayout(hbox1)
        vbox.addLayout(hbox2)
        vbox.addWidget(self.startButton)

        self.setLayout(vbox)
        self.setFixedSize(500,300)
        self.show()

        mainLayout = QGridLayout()

    def setWindow(self):
        if self.howMany.currentText() == "혼자하기":
            if self.nxn.currentText() == "3x3":
                widget.setCurrentIndex(4)
            elif self.nxn.currentText() == "4x4":
                widget.setCurrentIndex(5)
            else:
                widget.setCurrentIndex(6)
        else:
            if self.nxn.currentText() == "3x3":
                widget.setCurrentIndex(1)
            elif self.nxn.currentText() == "4x4":
                widget.setCurrentIndex(2)
            else:
                widget.setCurrentIndex(3)

    def back(self):
        widget.setCurrentIndex(0)

if __name__ == '__main__':
    app = QApplication(sys.argv)

    # 화면 전환용 widget 생성
    widget = QtWidgets.QStackedWidget()

    # 레이아웃 인스턴스 생성
    mainWindow = StartWindow()
    window = GameWindow(3)
    window2 = GameWindow(4)
    window3 = GameWindow(5)

    widget.addWidget(mainWindow)  # 인덱스 0
    widget.addWidget(window)
    widget.addWidget(window2)
    widget.addWidget(window3)

    widget.show()

    sys.exit(app.exec_())